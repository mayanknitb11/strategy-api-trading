"""
This module contains elements for interacting with the Groww API.
"""

import random
import uuid
from typing import Optional, Final

import requests

from gwapex_base.groww.enums import *
from gwapex_base.groww.exceptions import (
    GrowwClientException,
    GrowwClientTimeoutException,
)


class GrowwClient:
    """
    A client for interacting with the Groww API.
    """

    def __init__(self, token: str, key: str) -> None:
        """
        Initialize the GrowwClient with the given token and key.

        Args:
            token (str): API token for authentication.
            key (str): API key for authentication.
        """
        self.domain = "https://groww.in/apex/api/v1"
        self.token = token
        self.key = key

    def place_order(
        self,
        duration: Duration,
        exchange: Exchange,
        order_type: OrderType,
        price: float,
        product: Product,
        qty: int,
        segment: Segment,
        symbol: str,
        transaction_type: TransactionType,
        timeout: Optional[int] = None,
    ) -> dict:
        """
        Place a new order.

        Args:
            duration (Duration): The duration of the order.
            exchange (Exchange): The exchange to place the order on.
            order_type (OrderType): The type of order.
            price (float): The price of the order.
            product (Product): The product type.
            qty (int): The quantity of the order.
            segment (Segment): The segment of the order.
            symbol (str): The symbol to place the order for.
            transaction_type (TransactionType): The transaction type.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The placed order response.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = self.domain + "/order/create"
        order_reference_id = random.randint(10000000, 99999999)
        headers = self._build_headers()
        request_body = {
            "symbol": symbol,
            "quantity": qty,
            "price": price,
            "triggerPrice": 0,
            "duration": duration.value,
            "exchange": exchange.value,
            "segment": segment.value,
            "product": product.value,
            "orderType": order_type.value,
            "transactionType": transaction_type.value,
            "orderReferenceId": order_reference_id,
        }

        response = self._request_post(
            url=url,
            json=request_body,
            headers=headers,
            timeout=timeout,
        )
        return self._parse_response(response)

    def modify_order(
        self,
        order_type: OrderType,
        price: float,
        qty: int,
        segment: Segment,
        groww_order_id: Optional[str] = None,
        order_reference_id: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> dict:
        """
        Modify an existing order.

        Args:
            order_type (OrderType): The type of order.
            price (float): The price of the order.
            qty (int): The quantity of the order.
            segment (Segment): The segment of the order.
            groww_order_id (Optional[str]): The Groww order ID.
            order_reference_id (Optional[str]): The order reference ID.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The modified order response.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = self.domain + "/order/modify"
        headers = self._build_headers()
        request_body = {
            "quantity": qty,
            "price": price,
            "triggerPrice": 0,
            "growwOrderId": groww_order_id,
            "orderType": order_type.value,
            "segment": segment.value,
        }

        if order_reference_id is not None:
            request_body["orderReferenceId"] = order_reference_id
        response = self._request_post(
            url=url,
            json=request_body,
            headers=headers,
            timeout=timeout,
        )
        return self._parse_response(response)

    def cancel_order(
        self,
        groww_order_id: str,
        segment: Segment,
        order_reference_id: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> dict:
        """
        Cancel an existing order.

        Args:
            groww_order_id (str): The Groww order ID.
            segment (Segment): The segment of the order.
            order_reference_id (Optional[str]): The order reference ID.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The cancelled order response.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = self.domain + "/order/cancel"
        headers = self._build_headers()
        request_body = {
            "segment": segment.value,
            "growwOrderId": groww_order_id,
        }

        if order_reference_id is not None:
            request_body["referenceId"] = order_reference_id
        response = self._request_post(
            url=url,
            json=request_body,
            headers=headers,
            timeout=timeout,
        )
        return self._parse_response(response)

    def get_holdings_for_user(self, timeout: Optional[int] = None) -> dict:
        """
        Get the holdings for the user.

        Args:
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The user's holdings response.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = self.domain + "/holdings/user"
        response = self._request_get(
            url=url, headers=self._build_headers(), timeout=timeout
        )
        return self._parse_response(response)

    def get_latest_index_data(
        self,
        symbol: str,
        exchange: Exchange,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> dict:
        """
        Fetch the latest data for an index.

        Args:
            symbol (str): The symbol to fetch the data for.
            exchange (Exchange): The exchange to fetch the data from.
            segment (Segment): The segment to fetch the data from.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The latest index data.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = f"{self.domain}/live-data/latest-index/exchange/{exchange.value}/segment/{segment.value}/{symbol}"
        response = self._request_get(
            url=url,
            headers=self._build_headers(),
            timeout=timeout,
        )
        return self._parse_response(response)

    def get_latest_price_data(
        self,
        symbol: str,
        exchange: Exchange,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> dict:
        """
        Fetch the latest price data for an instrument.

        Args:
            symbol (str): The symbol to fetch the data for.
            exchange (Exchange): The exchange to fetch the data from.
            segment (Segment): The segment to fetch the data from.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The latest price data.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = f"{self.domain}/live-data/latest-price/exchange/{exchange.value}/segment/{segment.value}/{symbol}"
        response = self._request_get(
            url=url,
            headers=self._build_headers(),
            timeout=timeout,
        )
        return self._parse_response(response)

    def get_market_depth(
        self,
        symbol: str,
        exchange: Exchange,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> dict:
        """
        Fetch the market depth data for an instrument.

        Args:
            symbol (str): The symbol to fetch the data for.
            exchange (Exchange): The exchange to fetch the data from.
            segment (Segment): The segment to fetch the data from.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The market depth data.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = f"{self.domain}/live-data/market-depth/exchange/{exchange.value}/segment/{segment.value}/{symbol}"
        response = self._request_get(
            url=url,
            headers=self._build_headers(),
            timeout=timeout,
        )
        return self._parse_response(response)

    def get_order_detail(
        self,
        segment: Segment,
        groww_order_id: str,
        timeout: Optional[int] = None,
    ) -> dict:
        """
        Get the details of an order.

        Args:
            segment (Segment): The segment of the order.
            groww_order_id (str): The Groww order ID.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The order details response.

        Raises:
            GrowwClientException: If the request fails.
        """
        url: str = self.domain + "/detail/" + groww_order_id
        headers = self._build_headers()
        params = {"segment": segment.value}

        response = self._request_get(
            url=url,
            params=params,
            headers=headers,
            timeout=timeout,
        )
        return self._parse_response(response)

    def get_order_list(
        self,
        segment: Optional[Segment] = None,
        timeout: Optional[int] = None,
    ) -> dict:
        """
        Get a list of orders.

        Args:
            segment (Optional[Segment]): The segment of the orders.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The list of orders response.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = self.domain + "/order/list"

        headers = self._build_headers()
        params = {"segment": segment.value} if segment else {}

        response = self._request_get(
            url=url,
            params=params,
            headers=headers,
            timeout=timeout,
        )
        return self._parse_response(response)

    def get_position_for_symbol(
        self,
        symbol_isin: str,
        timeout: Optional[int] = None,
    ) -> dict:
        """
        Get the positions for a symbol.

        Args:
            symbol_isin (str): The symbol ISIN to get the positions for.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The positions response for the symbol.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = self.domain + "/positions/symbol"
        response = self._request_get(
            url=url,
            headers=self._build_headers(),
            params={"symbolIsin": symbol_isin},
            timeout=timeout,
        )
        return self._parse_response(response)

    def get_positions_for_user(
        self,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> dict:
        """
        Get the positions for the user for all the symbols they have positions in.

        Args:
            segment (Segment): The segment of the positions.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The user's positions response.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = self.domain + "/positions/user"
        response = self._request_get(
            url=url,
            params={"segment": segment.value},
            headers=self._build_headers(),
            timeout=timeout,
        )
        return self._parse_response(response)

    def get_trade_list_for_order(
        self,
        groww_order_id: str,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> dict:
        """
        Get the list of trades for a specific order.

        Args:
            groww_order_id (str): The Groww order ID.
            segment (Segment): The segment of the order.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The list of trades response.

        Raises:
            GrowwClientException: If the request fails.
        """
        trade_list_key: Final[str] = "tradeList"
        url = self.domain + "/order/trades/" + groww_order_id
        all_trades = []
        page = 0
        while page < 5:
            headers = self._build_headers()
            params = {"segment": segment.value, "page": page}

            response = self._request_get(
                url=url,
                params=params,
                headers=headers,
                timeout=timeout,
            )
            if not response.ok:
                break
            parsed_response = self._parse_response(response)
            if len(parsed_response.get(trade_list_key)) == 0:
                break
            all_trades = all_trades + parsed_response.get(trade_list_key)
            page += 1
        return {trade_list_key: all_trades}


    def get_available_margin_details(self, timeout: Optional[int] = None) -> dict:
        """
        Get the available margin details for the user.

        Args:
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The user's margin details response.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = self.domain + "/margins/detail/user"
        response = self._request_get(
            url=url, headers=self._build_headers(), timeout=timeout
        )
        return self._parse_response(response)

    def download_instrument_csv(self, path, timeout: Optional[int] = None):
        """
        Download the instrument CSV file.

        Args:
            path (str): The path to save the CSV file to.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The download response.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = "https://growwapi-assets.groww.in/instruments/instrument.csv"
        response = self._request_get(
            url=url, headers=self._build_headers(), timeout=timeout
        )
        with open(path, "wb") as f:
            f.write(response.content)

    def get_historical_candle_data(self, symbol: str, exchange: Exchange, segment: Segment, start_time_in_millis: str, end_time_in_millis: str, interval_in_minutes: Optional[int] = None, timeout: Optional[int] = None) -> dict:
        """
        Get the historical data for an instrument.

        Args:
            symbol (str): The symbol to fetch the data for.
            exchange (Exchange): The exchange to fetch the data from.
            segment (Segment): The segment to fetch the data from.
            start_time_in_millis (int): The start time in milliseconds.
            end_time_in_millis (int): The end time in milliseconds.
            interval_in_minutes (Optional[int]): The interval in minutes.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The historical data.

        Raises:
            GrowwClientException: If the request fails.
        """
        url = f"{self.domain}/historical/candle/range"
        params = {
            "exchange": exchange.value,
            "segment": segment.value,
            "symbol": symbol,
            "startTime": start_time_in_millis,
            "endTime": end_time_in_millis,
            "intervalInMinutes": interval_in_minutes,
        }
        response = self._request_get(
            url=url,
            headers=self._build_headers(),
            params=params,
            timeout=timeout,
        )
        return self._parse_response(response)

    def _build_headers(self) -> dict:
        """
        Build the headers for the API request.

        Returns:
            dict: The headers for the API request.
        """
        return {
            "x-request-id": str(uuid.uuid4()),
            "Authorization": "BEARER " + self.token,
            "x-api-key": self.key,
            "Content-Type": "application/json",
        }

    def _request_get(
        self,
        url: str,
        params: dict = None,
        headers: dict = None,
        timeout: Optional[int] = None,
        **kwargs: any,
    ) -> requests.Response:
        """
        Send a GET request to the API.

        Args:
            url (str): The URL to send the request to.
            params (dict): The parameters to send with the request.
            headers (dict): The headers to send with the request.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).
            **kwargs: Optional arguments that ``request`` takes.

        Returns:
            requests.Response: The response from the API.

        Raises:
            GrowwClientException: If the request fails.
        """
        try:
            return requests.get(
                url,
                params=params,
                headers=headers,
                timeout=timeout,
                **kwargs,
            )
        except requests.Timeout as e:
            raise GrowwClientTimeoutException(
                msg="The request to the Groww API timed out."
            ) from e

    def _request_post(
        self,
        url: str,
        json: dict = None,
        headers: dict = None,
        timeout: Optional[int] = None,
        **kwargs: any,
    ) -> requests.Response:
        """
        Send a POST request to the API.

        Args:
            url (str): The URL to send the request to.
            json (dict): The JSON data to send with the request.
            headers (dict): The headers to send with the request.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).
            **kwargs: Optional arguments that ``request`` takes.

        Returns:
            requests.Response: The response from the API.

        Raises:
            GrowwClientException: If the request fails.
        """
        try:
            return requests.post(
                url=url,
                json=json,
                headers=headers,
                timeout=timeout,
                **kwargs,
            )
        except requests.Timeout as e:
            raise GrowwClientTimeoutException(
                msg="The request to the Groww API timed out."
            ) from e

    def _parse_response(self, response: requests.Response) -> dict:
        """
        Parse the response from the API.

        Args:
            response (requests.Response): The response from the API.

        Returns:
            BaseGrowwResponse: The parsed response.

        Raises:
            GrowwClientException: If the request fails.
        """
        response_map = response.json()
        if response_map.get("status") == "FAILURE":
            error = response_map["error"]
            raise GrowwClientException(code=error["code"], msg=error["message"])
        if not response.ok:
            raise GrowwClientException(
                code=response.status_code,
                msg="The request to the Groww API failed.",
            )
        return dict(response_map["payload"])
