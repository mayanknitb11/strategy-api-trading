"""
This module contains custom exception classes for the Groww SDK.
"""


class BaseGrowwException(Exception):
    """
    Base class for exceptions in the Groww SDK.

    Attributes:
        msg (str): The error message associated with the exception.
    """

    def __init__(self, msg: str) -> None:
        """
        Initializes the GrowwException with an error message.

        Args:
            msg (str): The error message.
        """
        super().__init__(msg)
        self.msg = msg


class GrowwClientException(BaseGrowwException):
    """
    Base class for exceptions in the Groww SDK.

    Attributes:
        msg (str): The error message associated with the exception.
    """

    def __init__(self, msg: str, code: str) -> None:
        """
        Initializes the GrowwException with an error message.

        Args:
            msg (str): The error message.
        """
        super().__init__(msg)
        self.code = code


class GrowwClientTimeoutException(GrowwClientException):
    """
    Exception raised when a request to the Groww API times out.
    """

    def __init__(self, msg: str) -> None:
        """
        Initializes the GrowwClientTimeoutException with an error message.

        Args:
            msg (str): The error message.
        """
        super().__init__(msg, "504")


class GrowwFeedException(BaseGrowwException):
    """
    Exception raised when a connection to the Groww feed fails.
    """


class GrowwFeedConnectionException(GrowwFeedException):
    """
    Exception raised when a connection to the Groww feed fails.
    """


class GrowwFeedNotSubscribedException(GrowwFeedException):
    """
    Exception raised when get is attempted on an un-subscribed feed.
    """

    def __init__(self, msg: str, topic: str) -> None:
        """
        Initializes with an error message and the topic that was not subscribed to.

        Args:
            msg (str): The error message.
            topic (str): The topic that must be subscribed to receive messages.
        """
        super().__init__(msg)
        self.topic = topic
