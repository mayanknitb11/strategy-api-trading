"""
The module provides classes to subscribe to the Groww feed and get the feed data.
"""

import threading
from typing import Callable, Optional, Final, Type
from google.protobuf.json_format import MessageToDict

from gwapex_base.groww.enums import Exchange
from gwapex_base.groww.exceptions import GrowwFeedNotSubscribedException
from gwapex_base.groww.nats import NatsClient
from gwapex_base.groww.constants import SubscriptionTopic
from gwapex_base.groww.proto.stocks_socket_response_pb2 import (
    StocksSocketResponseProtoDto,
    StocksMarketInfoProto,
)
from gwapex_base.groww.proto.position_socket_pb2 import (
    PositionDetailProto,
)
from gwapex_base.groww.proto.stock_orders_socket_response_pb2 import (
    OrderDetailsBroadCastDto,
)


class Feed:
    """
    Feed class to store data for a given topic.
    """

    def __init__(
        self,
        topic: str,
        on_update: Optional[Callable[[], None]] = None,
    ) -> None:
        """Initialize a Feed with a topic and no data.

        Args:
            topic (str): The topic of the feed.
            on_update (Optional[Callable[[], None]]): The callback function to call on data update.
        """
        self.topic: str = topic
        self.on_update: Optional[Callable[[], None]] = on_update
        self.data: Optional[any] = None
        self._data_event: threading.Event = threading.Event()

    def update(self, data: any) -> None:
        """Update the feed with new data.

        Args:
            data (any): The new data for the feed.
        """
        self.data = data
        self._data_event.set()
        self.on_update() if self.on_update else None

    def get_data(self, timeout: float) -> Optional[any]:
        """Retrieve the data from the feed, waiting up to the specified timeout.

        Args:
            timeout (float): The maximum time to wait for data, in seconds.

        Returns:
            Optional[any]: The data if available, else None.
        """
        data_available = self._data_event.wait(timeout)
        return self.data if data_available else None

    def get_topic(self) -> str:
        """Retrieve the topic of the feed.

        Returns:
            str: The topic of the feed.
        """
        return self.topic


class FeedStation:
    """
    FeedStation class to store feeds for various topics.
    """

    def __init__(self) -> None:
        """Initialize a FeedStation with an empty feed dictionary."""
        self.feed_dict: dict[str, Feed] = {}

    def add_feed(self, key: str, feed: Feed) -> None:
        """Add a feed to the feed dictionary.

        Args:
            key (str): The key for the feed.
            feed (Feed): The feed object to add.
        """
        self.feed_dict[key] = feed

    def get_feed(self, key: str) -> Optional[Feed]:
        """Retrieve a feed from the feed dictionary.

        Args:
            key (str): The key for the feed.

        Returns:
            Optional[Feed]: The feed object if found, else None.
        """
        return self.feed_dict.get(key)

    def remove_feed(self, key: str) -> None:
        """Remove a feed from the feed dictionary.

        Args:
            key (str): The key for the feed to remove.
        """
        self.feed_dict.pop(key, None)


class GrowwFeed:
    """
    Used to subscribe to the Groww feed and get the feed data.

    One instance of GrowwFeed can be used to subscribe to multiple topics and get the feed data.

    Note:
        Only one subscription can be created to each topic by a single instance of GrowwFeed.
    """

    _GROWW_SOCKET_URL: Final[str] = "ws://socket-web.groww.in"
    _nats_clients: dict[tuple[str, str], NatsClient] = {}

    def __init__(self, socket_token: str, socket_key: str) -> None:
        """
        Initialize the GrowwFeed class with socket token and key.

        Args:
            socket_token (str): The socket token.
            socket_key (str): The socket key.

        Raises:
            GrowwFeedConnectionException: If the socket connection fails.
        """
        self._feed_station: FeedStation = FeedStation()
        client_key = (socket_token, socket_key)
        if client_key not in GrowwFeed._nats_clients:
            GrowwFeed._nats_clients[client_key] = NatsClient(
                GrowwFeed._GROWW_SOCKET_URL,
                socket_token,
                socket_key,
                self._update_feed_data,
            )
        self._nats_client = GrowwFeed._nats_clients[client_key]

    def subscribe_derivatives_live(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the live data of a derivatives contract.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._subscribe(
            SubscriptionTopic.get_derivatives_ltp_topic(subscription_key),
            on_data_received,
        )

    def unsubscribe_derivatives_live(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the live data of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._unsubscribe(
            SubscriptionTopic.get_derivatives_ltp_topic(subscription_key)
        )

    def subscribe_derivatives_market_depth(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the market depth of a derivatives contract.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._subscribe(
            SubscriptionTopic.get_derivatives_market_depth_topic(subscription_key),
            on_data_received,
        )

    def unsubscribe_derivatives_market_depth(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the market depth of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._unsubscribe(
            SubscriptionTopic.get_derivatives_market_depth_topic(subscription_key)
        )

    def subscribe_derivatives_order_updates(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the order updates of a derivatives contract.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._subscribe(
            SubscriptionTopic.get_derivatives_order_updates_topic(subscription_key),
            on_data_received,
        )

    def unsubscribe_derivatives_order_updates(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the order updates of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._unsubscribe(
            SubscriptionTopic.get_derivatives_order_updates_topic(subscription_key),
        )

    def subscribe_derivatives_position_updates(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the position updates of a derivatives contract.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._subscribe(
            SubscriptionTopic.get_derivatives_position_updates_topic(subscription_key),
            on_data_received,
        )

    def unsubscribe_derivatives_position_updates(
        self,
        subscription_key: str,
    ) -> bool:
        """
        Unsubscribe from the position updates of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._unsubscribe(
            SubscriptionTopic.get_derivatives_position_updates_topic(subscription_key),
        )

    def subscribe_indices_live(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the live data of an index.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._subscribe(
            SubscriptionTopic.get_index_ltp_topic(subscription_key),
            on_data_received,
        )

    def unsubscribe_indices_live(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the live data of an index.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._unsubscribe(
            SubscriptionTopic.get_index_ltp_topic(subscription_key)
        )

    def subscribe_market_info(
        self,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the market information.

        Subscription can be created only once for a given subscription key.

        Args:
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._subscribe(
            SubscriptionTopic.get_market_info_topic(),
            on_data_received,
        )

    def unsubscribe_market_info(self) -> bool:
        """
        Unsubscribe from the market information.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._unsubscribe(SubscriptionTopic.get_market_info_topic())

    def subscribe_stocks_live(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the live data of a stock.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._subscribe(
            SubscriptionTopic.get_equity_ltp_topic(subscription_key),
            on_data_received,
        )

    def unsubscribe_stocks_live(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the live data of a stock.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._unsubscribe(
            SubscriptionTopic.get_equity_ltp_topic(subscription_key),
        )

    def subscribe_stocks_market_depth(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the market depth of a stock.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._subscribe(
            SubscriptionTopic.get_equity_market_depth_topic(subscription_key),
            on_data_received,
        )

    def unsubscribe_stocks_market_depth(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the market depth of a stock.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._unsubscribe(
            SubscriptionTopic.get_equity_market_depth_topic(subscription_key)
        )

    def subscribe_stocks_order_updates(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the order updates of a stock.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._subscribe(
            SubscriptionTopic.get_equity_order_updates_topic(subscription_key),
            on_data_received,
        )

    def unsubscribe_stocks_order_updates(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the order updates of a stock.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._unsubscribe(
            SubscriptionTopic.get_equity_order_updates_topic(subscription_key),
        )

    def get_derivatives_live(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[dict[str, any]]:
        """
        Get the live data of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[dict[str, any]]: The live price data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = self._get_feed(
            SubscriptionTopic.get_derivatives_ltp_topic(subscription_key),
            timeout,
        )
        if data is None:
            return None

        proto_data = self._parse_data_to_proto_model(data, StocksSocketResponseProtoDto)
        return self._transform_proto_data_to_dict(proto_data.stockLivePrice)

    def get_derivatives_ltp(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[float]:
        """
        Get the last traded price (LTP) of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[float]: The last traded price, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data: Optional[dict[str, any]] = self.get_derivatives_live(
            subscription_key,
            timeout,
        )
        return data.get("ltp") if data else None

    def get_derivatives_market_depth(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[dict[str, any]]:
        """
        Get the market depth of an option contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[dict[str, any]]: The market depth data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = self._get_feed(
            SubscriptionTopic.get_derivatives_market_depth_topic(subscription_key),
            timeout,
        )
        if data is None:
            return None

        proto_data = self._parse_data_to_proto_model(data, StocksSocketResponseProtoDto)
        return self._transform_proto_data_to_dict(proto_data.stocksMarketDepth)

    def get_derivatives_order_update(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[dict[str, any]]:
        """
        Get the order updates of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[dict[str, any]]: The order details, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = self._get_feed(
            SubscriptionTopic.get_derivatives_order_updates_topic(subscription_key),
            timeout,
        )
        if data is None:
            return None

        proto_data = self._parse_data_to_proto_model(data, OrderDetailsBroadCastDto)
        return self._transform_proto_data_to_dict(proto_data.orderDetailUpdateDto)

    def get_derivatives_position_update(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[dict[str, any]]:
        """
        Get the position updates of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[dict[str, any]]: The exchange wise position, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = self._get_feed(
            SubscriptionTopic.get_derivatives_position_updates_topic(subscription_key),
            timeout,
        )
        if data is None:
            return None

        proto_data = self._parse_data_to_proto_model(data, PositionDetailProto)
        return {
            "symbolIsin": proto_data.positionInfo.symbolIsin,
            "exchangePosition": {
                Exchange.BSE: self._transform_proto_data_to_dict(
                    proto_data.positionInfo.BSE
                ),
                Exchange.NSE: self._transform_proto_data_to_dict(
                    proto_data.positionInfo.NSE
                ),
            },
        }

    def get_indices_live(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[dict[str, any]]:
        """
        Get the live data of an index.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[dict[str, any]]: The live index data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = self._get_feed(
            SubscriptionTopic.get_index_ltp_topic(subscription_key),
            timeout,
        )
        if data is None:
            return None

        proto_data = self._parse_data_to_proto_model(data, StocksSocketResponseProtoDto)
        return self._transform_proto_data_to_dict(proto_data.stocksLiveIndices)

    def get_indices_value(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[float]:
        """
        Get the last value of an index.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[float]: The last value of the Index, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data: Optional[dict[str, any]] = self.get_indices_live(
            subscription_key,
            timeout,
        )
        return data.get("value") if data else None

    def get_market_info(self, timeout: float = 5) -> Optional[str]:
        """
        Get the market information.

        Args:
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[str]: The market information, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = self._get_feed(SubscriptionTopic.get_market_info_topic(), timeout)
        if data is None:
            return None

        proto_data = self._parse_data_to_proto_model(data, StocksMarketInfoProto)
        return proto_data.message

    def get_stocks_live(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[dict[str, any]]:
        """
        Get the live data of a stock.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[dict[str, any]]: The live price data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = self._get_feed(
            SubscriptionTopic.get_equity_ltp_topic(subscription_key),
            timeout,
        )
        if data is None:
            return None

        proto_data = self._parse_data_to_proto_model(data, StocksSocketResponseProtoDto)
        return self._transform_proto_data_to_dict(proto_data.stockLivePrice)

    def get_stocks_ltp(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[float]:
        """
        Get the last traded price (LTP) of a stock.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[float]: The last traded price, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data: Optional[dict[str, any]] = self.get_stocks_live(subscription_key, timeout)
        return data.get("ltp") if data else None

    def get_stocks_market_depth(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[dict[str, any]]:
        """
        Get the market depth of a stock.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[dict[str, any]]: The market depth data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = self._get_feed(
            SubscriptionTopic.get_equity_market_depth_topic(subscription_key),
            timeout,
        )
        if data is None:
            return None

        proto_data = self._parse_data_to_proto_model(data, StocksSocketResponseProtoDto)
        return self._transform_proto_data_to_dict(proto_data.stocksMarketDepth)

    def get_stocks_order_update(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[dict[str, any]]:
        """
        Get the order updates of a stock.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[dict[str, any]]: The order details, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = self._get_feed(
            SubscriptionTopic.get_equity_order_updates_topic(subscription_key),
            timeout,
        )
        if data is None:
            return None

        proto_data = self._parse_data_to_proto_model(data, OrderDetailsBroadCastDto)
        return self._transform_proto_data_to_dict(proto_data.orderDetailUpdateDto)

    def _update_feed_data(self, topic: str, data: any) -> None:
        """
        Update the feed data for a given topic.

        Args:
            topic (str): The feed key.
            data (any): The data to update.
        """
        self._feed_station.get_feed(topic).update(data)

    def _subscribe(
        self,
        topic: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to a given topic.

        Subscription can be created only once for a given topic.

        Args:
            topic (str): The topic to subscribe to.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        if self._nats_client.is_subscribed(topic):
            return False

        self._feed_station.add_feed(topic, Feed(topic, on_data_received))
        return self._nats_client.subscribe_topic(topic)

    def _unsubscribe(self, topic: str) -> bool:
        """
        Unsubscribe from a given topic.

        Args:
            topic (str): The topic to unsubscribe from.

        Returns:
            bool: True if unsubscribed, else False.
        """
        if not self._nats_client.is_subscribed(topic):
            return False

        is_unsubed: bool = self._nats_client.unsubscribe_topic(topic)
        self._feed_station.remove_feed(topic)
        return is_unsubed

    def _get_feed(self, topic: str, timeout: float) -> Optional[any]:
        """
        Get the feed for a given subscription topic.

        Args:
            topic (str): The subscription topic.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[any]: The feed data if available, else None.

        Raises:
            GrowwFeedNotSubscribedException: If the feed is not subscribed.
        """
        feed: Feed = self._feed_station.get_feed(topic)
        if not feed:
            raise GrowwFeedNotSubscribedException(
                f"Feed not subscribed for topic! A subscription is required to get the data.",
                topic,
            )
        return feed.get_data(timeout)

    def _parse_data_to_proto_model(
        self,
        data: any,
        proto: Type[any],
    ) -> any:
        """
        Parse the proto object to the model object.

        Args:
            data (any): The data to parse.
            proto (Type): The proto class.
        """
        proto_object = proto()
        proto_object.ParseFromString(data)
        return proto_object

    def _transform_proto_data_to_dict(self, proto_data: any) -> dict[str, any]:
        """
        Parse the proto object to the model object.

        Args:
            proto_data (any): The data to parse.
            model (Type[BaseGrowwModel]): The model class.

        Returns:
            dict[str, any]: The model object.
        """
        return MessageToDict(proto_data, preserving_proto_field_name=True)
