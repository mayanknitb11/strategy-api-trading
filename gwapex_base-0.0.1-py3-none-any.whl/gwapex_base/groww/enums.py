"""
Contains all the enums used in the Groww Base SDK for representing various trading parameters
"""

from aenum import MultiValueEnum
from typing_extensions import Self


class BaseGrowwEnum(MultiValueEnum):
    """Base class for all Groww Enums"""

    @classmethod
    def values(cls) -> list[Self]:
        """
        Returns a list of all the values of the enum

        Returns:
            list: The values of the enum
        """
        return list(cls)


class AmoStatus(BaseGrowwEnum):
    """
    Represents the status of an After Market Order (AMO) in the trading system.
    """

    NA: str = "NA"
    """Status not available"""

    PENDING: str = "PENDING"
    """Order is pending for execution"""

    DISPATCHED: str = "DISPATCHED"
    """Order has been dispatched for execution"""

    PARKED: str = "PARKED"
    """Order is parked for later execution"""

    PLACED: str = "PLACED"
    """Order has been placed in the market"""

    FAILED: str = "FAILED"
    """Order execution has failed"""

    MARKET: str = "MARKET"
    """Order is a market order"""


class Duration(BaseGrowwEnum):
    """
    Specifies how long an order remains active in the trading system before it is automatically cancelled
    if not executed.
    """

    DAY: str = "DAY"
    """Valid until market close on the same trading day"""

    EOS: str = "EOS"
    """End of Session - Valid until the end of current trading session"""

    IOC: str = "IOC"
    """Immediate or Cancel - Must be filled immediately (fully/partially) or cancelled"""

    GTC: str = "GTC"
    """Good Till Cancelled - Remains active until explicitly cancelled by trader"""

    GTD: str = "GTD"
    """Good Till Date - Valid until a specific date set by trader"""


class EquityType(BaseGrowwEnum):
    """
    Represents the type of equity instrument being traded, such as stocks, futures, options, etc.
    """

    STOCKS: str = "STOCKS"
    """Regular equity shares of a company"""

    FUTURE: str = "FUTURE"
    """Derivatives contract to buy/sell an asset at a future date"""

    OPTION: str = "OPTION"
    """Derivatives contract giving the right to buy/sell an asset at a future date"""

    ETF: str = "ETF"
    """Exchange Traded Fund - Basket of securities traded on an exchange"""

    INDEX: str = "INDEX"
    """Index - Composite value of a group of stocks representing a market"""

    BONDS: str = "BONDS"
    """Debt instrument issued by a government or corporation"""


class Exchange(BaseGrowwEnum):
    """
    Represents the stock exchanges where the trades can be executed.
    """

    BSE: str = "BSE"
    """Bombay Stock Exchange - Asia's oldest exchange, known for SENSEX index"""

    MCX: str = "MCX"
    """Multi Commodity Exchange - Leading commodity exchange in India"""

    MCXSX: str = "MCXSX"
    """MCX Stock Exchange - Former stock exchange in India"""

    NCDEX: str = "NCDEX"
    """National Commodity and Derivatives Exchange - Leading agri-commodity exchange"""

    NSE: str = "NSE"
    """National Stock Exchange - India's largest exchange by trading volume"""

    US: str = "US"
    """United States Stock Exchange"""


class OrderStatus(BaseGrowwEnum):
    """
    Represents the status of an order in the trading system.
    """

    ACKED: str = "ACKED"
    """Order has been acknowledged by the system"""

    APPROVED: str = "APPROVED"
    """Order has been approved and is ready for execution"""

    CANCELLATION_REQUESTED: str = "CANCELLATION_REQUESTED"
    """Request to cancel the order has been initiated"""

    CANCELLED: str = "CANCELLED"
    """Order has been cancelled"""

    COMPLETED: str = "COMPLETED"
    """Order has been completed"""

    DELIVERY_AWAITED: str = "DELIVERY_AWAITED"
    """Order has been executed and waiting for delivery"""

    EXECUTED: str = "EXECUTED"
    """Order has been successfully executed"""

    FAILED: str = "FAILED"
    """Order execution has failed"""

    MODIFICATION_REQUESTED: str = "MODIFICATION_REQUESTED"
    """Request to modify the order has been initiated"""

    NEW: str = "NEW"
    """Order is newly created and pending for further processing"""

    REJECTED: str = "REJECTED"
    """Order has been rejected by the system"""

    TRIGGER_PENDING: str = "TRIGGER_PENDING"
    """Order is waiting for a trigger event to be executed"""

    def is_open(self) -> bool:
        """
        Check if the order status indicates an open order.

        Returns:
            bool: True if the order is open, False otherwise
        """
        return self in (
            OrderStatus.NEW,
            OrderStatus.ACKED,
            OrderStatus.TRIGGER_PENDING,
            OrderStatus.APPROVED,
            OrderStatus.CANCELLATION_REQUESTED,
            OrderStatus.MODIFICATION_REQUESTED,
        )


class OrderType(BaseGrowwEnum):
    """
    Defines how the order will be executed in terms of price. Different order types offer
    varying levels of price control and execution certainty.
    """

    LIMIT: str = "L"
    """Specify exact price, may not get filled immediately but ensures price control"""

    MARKET: str = "MKT"
    """Immediate execution at best available price, no price guarantee"""

    STOP_LOSS: str = "SL"
    """Protection order that triggers at specified price to limit losses"""

    STOP_LOSS_MARKET: str = "SL-M", "SL_M"
    """Stop Loss Market - Market order triggered at specified price to limit losses"""


class Product(BaseGrowwEnum):
    """
    Specifies the trading product type which determines factors like leverage, holding period,
    margin requirements, and settlement rules.
    """

    ARBITRAGE: str = "ARB"
    """For exploiting price differences between markets, requires quick execution"""

    BO: str = "BO"
    """Bracket Order - Set target and stop-loss in a single order for risk management"""

    CNC: str = "CNC"
    """Cash and Carry - For delivery-based equity trading with full upfront payment"""

    CO: str = "CO"
    """Cover Order - Intraday trading with built-in stop-loss for risk protection"""

    NORMAL_MARGIN: str = "NRML"
    """Regular margin trading allowing overnight positions with standard leverage"""

    MIS: str = "MIS"
    """Margin Intraday Square-off - Higher leverage but must close by day end"""

    MTF: str = "MTF"
    """Margin Trading Facility - Allows borrowing funds for delivery trading"""


class Segment(BaseGrowwEnum):
    """
    Defines the market segment which determines the type of instruments that can be traded
    and their associated rules and regulations.
    """

    CASH: str = "CASH"
    """Regular equity market for trading stocks with delivery option"""

    CURRENCEY: str = "CURRENCY"
    """Currency segment for trading forex pairs and currency derivatives"""

    COMMODITY: str = "COMMODITY"
    """Commodity segment for trading physical commodities and derivatives"""

    DERIVATIVE: str = "FNO"
    """Futures and Options segment for trading derivatives contracts"""


class TransactionType(BaseGrowwEnum):
    """
    Indicates whether the trader is entering a long position (buying) or short position (selling).
    Determines the direction of the trade and potential profit/loss scenarios.
    """

    BUY: str = "BUY", "B"
    """Long position - Profit from price increase, loss from price decrease"""

    SELL: str = "SELL", "S"
    """Short position - Profit from price decrease, loss from price increase"""
