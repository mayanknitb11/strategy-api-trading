"""
The module provides utility functions for file operations.
"""

import os


def get_cwd(file: str = __file__) -> str:
    """
    Get the current working directory of the file.
    
    Args:
        file (str): The file path to get the directory of. Defaults to the current
            file.
    Returns:
        str: The current working directory
    """
    return os.path.dirname(os.path.abspath(file))


def generate_nats_cred_file(jwt_token, nkey_seed):
    """
    Generate user credentials file with jwt token and nkey seed.
    :param jwt_token:
    :param nkey_seed:
    :return:
    """
    content = f"""-----BEGIN NATS USER JWT-----
{jwt_token}
------END NATS USER JWT------

************************* IMPORTANT *************************
NKEY Seed printed below can be used to sign and prove identity.
NKEYs are sensitive and should be treated as secrets.

-----BEGIN USER NKEY SEED-----
{nkey_seed}
------END USER NKEY SEED------

*************************************************************
"""
    file_path = get_cwd() + '/user.creds'
    with open(file_path, 'w', encoding='UTF-8') as file:
        file.write(content)
    return file_path
