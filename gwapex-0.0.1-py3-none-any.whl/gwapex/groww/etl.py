"""
ETL pipelines to generate Groww models.

This module contains the base ETL class and a specific implementation for instrument data.
"""

from abc import ABC, abstractmethod
from typing import Type
import logging

from gwapex_base.common.files import get_cwd
from gwapex.groww.models import BaseGrowwModel, OrderDetailDto

from gwapex.groww.client import StructuredGrowwClient
from gwapex.common.csv import read_csv_and_transform
from gwapex.groww.enums import InstrumentType
from gwapex.groww.models import (
    IndexInstrument,
    IndexFutureContract,
    IndexOptionContract,
    Instrument,
    StockInstrument,
    StockFutureContract,
    StockOptionContract,
)
from gwapex.groww.stores import (
    BaseGrowwDataStore,
    InstrumentGrowwDataStore,
    OrderListGrowwDataStore,
)

logger = logging.getLogger(__name__)


class BaseGrowwEtl(ABC):
    """
    ETL class for Groww data.
    """

    def __init__(self, data_store: BaseGrowwDataStore) -> None:
        """
        Initialize the GrowwEtl.

        Args:
            data_store (BaseGrowwDataStore): The data store to load data into.
        """
        self.data_store = data_store

    @abstractmethod
    def extract(self) -> list[dict]:
        """
        Extract dictionaries from the raw data.

        Returns:
            list[dict]: The extracted dictionaries.
        """

    @abstractmethod
    def transform(self, extracted_data: list[dict]) -> list[BaseGrowwModel]:
        """
        Transform the data models.

        Args:
            extracted_data (list[dict]): The extracted data.

        Returns:
            list[BaseGrowwModel]: The transformed data models.
        """

    def load(self, data: list[BaseGrowwModel]) -> None:
        """
        Load the data into the data store.

        Args:
            data (list[BaseGrowwModel]): The data to load.
        """
        self.data_store.load(data)

    def run(self) -> None:
        """
        Run the ETL pipeline.
        """
        extracted_data = self.extract()
        transformed_data = self.transform(extracted_data)
        self.load(transformed_data)


class InstrumentCsvGrowwEtl(BaseGrowwEtl):
    """
    ETL class for instrument data.
    """

    def __init__(
        self,
        data_store: InstrumentGrowwDataStore,
        groww_client:StructuredGrowwClient) -> None:
        """
        Initialize the InstrumentGrowwEtl.

        Args:
            data_store (InstrumentGrowwDataStore): The data store to load instrument data into.
        """
        super().__init__(data_store)
        self.groww_client = groww_client
        self.type_to_model: dict[InstrumentType, Type[BaseGrowwModel]] = {
            InstrumentType.INDEX: IndexInstrument,
            InstrumentType.INDEX_FUTURE: IndexFutureContract,
            InstrumentType.INDEX_OPTION: IndexOptionContract,
            InstrumentType.STOCK: StockInstrument,
            InstrumentType.STOCK_FUTURE: StockFutureContract,
            InstrumentType.STOCK_OPTION: StockOptionContract,
        }

    def extract(self) -> list[dict]:
        """
        Extract dictionaries from the raw data.

        Returns:
            list[dict]: The extracted dictionaries.
        """
        path = get_cwd(__file__) + "/../instruments.csv"
        self.groww_client.download_instrument_csv(path)
        return read_csv_and_transform(path)

    def transform(self, extracted_data: list[dict]) -> list[BaseGrowwModel]:
        """
        Transform the data models.

        Args:
            extracted_data (list[dict]): The extracted data.

        Returns:
            list[BaseGrowwModel]: The transformed data models.
        """
        instruments: list[Instrument] = []
        for data in extracted_data:
            instrument_type = InstrumentType(data["instrument_type"])
            model = self.type_to_model[instrument_type]
            instruments.append(model(**data))
        return instruments


class OrderListApiGrowwEtl(BaseGrowwEtl):
    """
    ETL class for order data.
    """

    def __init__(
        self,
        data_store: OrderListGrowwDataStore,
        groww_client: StructuredGrowwClient,
    ) -> None:
        """
        Initialize the OrderListGrowwEtl.

        Args:
            data_store (OrderListGrowwDataStore): The data store to load order data into.
            groww_client (StructuredGrowwClient): The Groww client to fetch order data.
        """
        super().__init__(data_store)
        self.groww_client = groww_client

    def extract(self) -> list[OrderDetailDto]:
        """
        Fetch order list from the Groww API.

        Returns:
            list[OrderDetailDto]: The extracted dictionaries.
        """
        response = self.groww_client.get_order_list()
        return response.order_list

    def transform(self, extracted_data: list[OrderDetailDto]) -> list[BaseGrowwModel]:
        """
        No transformation required for order data.

        Args:
            extracted_data (list[OrderDetailDto]): The extracted data.

        Returns:
            list[BaseGrowwModel]: The transformed data models.
        """
        return extracted_data
