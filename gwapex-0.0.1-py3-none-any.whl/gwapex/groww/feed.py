"""
The module provides classes to subscribe to the Groww feed and get the feed data.
"""

from typing import Optional, Final

from gwapex_base.groww.feed import GrowwFeed
from gwapex.groww.models import (
    LivePriceData,
    LiveIndexData,
    MarketDepthData,
    OrderDetailDto,
    ExchangePosition,
)


class StructuredGrowwFeed(GrowwFeed):
    """
    A structured feed manager for Groww feed providing methods to subscribe to topics and get structured feed data.

    One instance of GrowwFeed can be used to subscribe to multiple topics and get the feed data.

    Note:
        Only one subscription can be created to each topic by a single instance of GrowwFeed.
    """

    _GROWW_SOCKET_URL: Final[str] = "ws://socket-web.groww.in"

    def __init__(self, socket_token: str, socket_key: str) -> None:
        """
        Initialize the GrowwFeed class with socket token and key.

        Args:
            socket_token (str): The socket token.
            socket_key (str): The socket key.

        Raises:
            GrowwFeedConnectionException: If the socket connection fails.
        """
        super().__init__(socket_token, socket_key)

    def get_derivatives_live(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[LivePriceData]:
        """
        Get the live data of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[LivePriceData]: The live price data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = super().get_derivatives_live(subscription_key, timeout)
        return LivePriceData(**data) if data else None

    def get_derivatives_ltp(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[float]:
        """
        Get the last traded price (LTP) of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[float]: The last traded price, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data: Optional[LivePriceData] = self.get_derivatives_live(subscription_key, timeout)
        return data.ltp if data else None

    def get_derivatives_market_depth(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[MarketDepthData]:
        """
        Get the market depth of an option contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[MarketDepthData]: The market depth data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = super().get_derivatives_market_depth(subscription_key, timeout)
        return MarketDepthData(**data) if data else None

    def get_derivatives_order_update(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[OrderDetailDto]:
        """
        Get the order updates of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[OrderDetailDto]: The order details, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = super().get_derivatives_order_update(subscription_key, timeout)
        return OrderDetailDto(**data) if data else None

    def get_derivatives_position_update(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[ExchangePosition]:
        """
        Get the position updates of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[ExchangePosition]: The exchange wise position, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = super().get_derivatives_position_update(subscription_key, timeout)
        return ExchangePosition(**data) if data else None

    def get_indices_live(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[LiveIndexData]:
        """
        Get the live data of an index.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[LiveIndexData]: The live index data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = super().get_indices_live(subscription_key, timeout)
        return LiveIndexData(**data) if data else None

    def get_indices_value(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[float]:
        """
        Get the last value of an index.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[float]: The last value of the Index, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data: Optional[LiveIndexData] = self.get_indices_live(
            subscription_key,
            timeout,
        )
        return data.value if data else None

    def get_stocks_live(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[LivePriceData]:
        """
        Get the live data of a stock.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[LivePriceData]: The live price data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = super().get_stocks_live(subscription_key, timeout)
        return LivePriceData(**data) if data else None

    def get_stocks_ltp(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[float]:
        """
        Get the last traded price (LTP) of a stock.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[float]: The last traded price, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data: Optional[LivePriceData] = self.get_stocks_live(subscription_key, timeout)
        return data.ltp if data else None

    def get_stocks_market_depth(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[MarketDepthData]:
        """
        Get the market depth of a stock.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[MarketDepthData]: The market depth data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = super().get_stocks_market_depth(subscription_key, timeout)
        return MarketDepthData(**data) if data else None

    def get_stocks_order_update(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[OrderDetailDto]:
        """
        Get the order updates of a stock.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[OrderDetailDto]: The order details, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        data = super().get_stocks_order_update(subscription_key, timeout)
        return OrderDetailDto(**data) if data else None
