"""
This module contains elements for interacting with the Groww API.
"""

from typing import Optional

from gwapex_base.groww.client import GrowwClient
from gwapex_base.groww.enums import *
from gwapex.groww.responses import (
    CancelOrderResponse,
    HoldingsResponse,
    LatestIndexResponse,
    LatestPriceResponse,
    MarketDepthResponse,
    ModifyOrderResponse,
    PositionsResponse,
    OrderDetailResponse,
    OrderListResponse,
    OrderResponse,
    SymbolToPositionsResponse,
    TradeResponse, MarginAvailableResponse,
    HistoricalCandleDataResponse,
)


class StructuredGrowwClient(GrowwClient):
    """
    A structured client for interacting with the Groww API.
    
    This is built on top of the GrowwClient and provides structured responses for the API calls.
    """

    def __init__(self, token: str, key: str) -> None:
        """
        Initialize the GrowwClient with the given token and key.

        Args:
            token (str): API token for authentication.
            key (str): API key for authentication.
        """
        super().__init__(token=token, key=key)

    def place_order(
        self,
        duration: Duration,
        exchange: Exchange,
        order_type: OrderType,
        price: float,
        product: Product,
        qty: int,
        segment: Segment,
        symbol: str,
        transaction_type: TransactionType,
        timeout: Optional[int] = None,
    ) -> OrderResponse:
        """
        Place a new order.

        Args:
            duration (Duration): The duration of the order.
            exchange (Exchange): The exchange to place the order on.
            order_type (OrderType): The type of order.
            price (float): The price of the order.
            product (Product): The product type.
            qty (int): The quantity of the order.
            segment (Segment): The segment of the order.
            symbol (str): The symbol to place the order for.
            transaction_type (TransactionType): The transaction type.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            OrderResponse: The placed order response.

        Raises:
            GrowwClientException: If the request fails.
        """
        response: dict[str, any] = super().place_order(
            duration=duration,
            exchange=exchange,
            order_type=order_type,
            price=price,
            product=product,
            qty=qty,
            segment=segment,
            symbol=symbol,
            transaction_type=transaction_type,
            timeout=timeout,
        )
        return OrderResponse(**response)

    def modify_order(
        self,
        order_type: OrderType,
        price: float,
        qty: int,
        segment: Segment,
        groww_order_id: Optional[str] = None,
        order_reference_id: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> ModifyOrderResponse:
        """
        Modify an existing order.

        Args:
            order_type (OrderType): The type of order.
            price (float): The price of the order.
            qty (int): The quantity of the order.
            segment (Segment): The segment of the order.
            groww_order_id (Optional[str]): The Groww order ID.
            order_reference_id (Optional[str]): The order reference ID.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            ModifyOrderResponse: The modified order response.

        Raises:
            GrowwClientException: If the request fails.
        """
        response: dict[str, any] = super().modify_order(
            order_type=order_type,
            price=price,
            qty=qty,
            segment=segment,
            groww_order_id=groww_order_id,
            order_reference_id=order_reference_id,
            timeout=timeout,
        )
        return ModifyOrderResponse(**response)

    def cancel_order(
        self,
        groww_order_id: str,
        segment: Segment,
        order_reference_id: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> CancelOrderResponse:
        """
        Cancel an existing order.

        Args:
            groww_order_id (str): The Groww order ID.
            segment (Segment): The segment of the order.
            order_reference_id (Optional[str]): The order reference ID.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            CancelOrderResponse: The cancelled order response.

        Raises:
            GrowwClientException: If the request fails.
        """
        response: dict[str, any] = super().cancel_order(
            groww_order_id=groww_order_id,
            segment=segment,
            order_reference_id=order_reference_id,
            timeout=timeout,
        )
        return CancelOrderResponse(**response)

    def get_holdings_for_user(self, timeout: Optional[int] = None) -> HoldingsResponse:
        """
        Get the holdings for the user.

        Args:
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            HoldingsResponse: The user's holdings response.

        Raises:
            GrowwClientException: If the request fails.
        """
        response: dict[str, any] = super().get_holdings_for_user(timeout=timeout)
        return HoldingsResponse(**response)

    def get_latest_index_data(
        self,
        symbol: str,
        exchange: Exchange,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> LatestIndexResponse:
        """
        Fetch the latest data for an index.

        Args:
            symbol (str): The symbol to fetch the data for.
            exchange (Exchange): The exchange to fetch the data from.
            segment (Segment): The segment to fetch the data from.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            LatestIndexResponse: The latest index data.

        Raises:
            GrowwClientException: If the request fails.
        """
        response: dict[str, any] = super().get_latest_index_data(
            symbol=symbol,
            exchange=exchange,
            segment=segment,
            timeout=timeout,
        )
        return LatestIndexResponse(**response)

    def get_latest_price_data(
        self,
        symbol: str,
        exchange: Exchange,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> LatestPriceResponse:
        """
        Fetch the latest price data for an instrument.

        Args:
            symbol (str): The symbol to fetch the data for.
            exchange (Exchange): The exchange to fetch the data from.
            segment (Segment): The segment to fetch the data from.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            LatestPriceResponse: The latest price data.

        Raises:
            GrowwClientException: If the request fails.
        """
        response: dict[str, any] = super().get_latest_price_data(
            symbol=symbol,
            exchange=exchange,
            segment=segment,
            timeout=timeout,
        )
        return LatestPriceResponse(**response)

    def get_market_depth(
        self,
        symbol: str,
        exchange: Exchange,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> MarketDepthResponse:
        """
        Fetch the market depth data for an instrument.

        Args:
            symbol (str): The symbol to fetch the data for.
            exchange (Exchange): The exchange to fetch the data from.
            segment (Segment): The segment to fetch the data from.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            MarketDepthResponse: The market depth data.

        Raises:
            GrowwClientException: If the request fails.
        """
        response: dict[str, any] = super().get_market_depth(
            symbol=symbol,
            exchange=exchange,
            segment=segment,
            timeout=timeout,
        )
        return MarketDepthResponse(**response)

    def get_order_detail(
        self,
        segment: Segment,
        groww_order_id: str,
        timeout: Optional[int] = None,
    ) -> OrderDetailResponse:
        """
        Get the details of an order.

        Args:
            segment (Segment): The segment of the order.
            groww_order_id (str): The Groww order ID.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            OrderDetailResponse: The order details response.

        Raises:
            GrowwClientException: If the request fails.
        """
        response: dict[str, any] = super().get_order_detail(
            segment=segment,
            groww_order_id=groww_order_id,
            timeout=timeout,
        )
        return OrderDetailResponse(**response)

    def get_order_list(
        self,
        segment: Optional[Segment] = None,
        timeout: Optional[int] = None,
    ) -> OrderListResponse:
        """
        Get a list of orders.

        Args:
            segment (Optional[Segment]): The segment of the orders.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            OrderListResponse: The list of orders response.

        Raises:
            GrowwClientException: If the request fails.
        """
        response: dict[str, any] = super().get_order_list(segment=segment, timeout=timeout)
        return OrderListResponse(**response)

    def get_position_for_symbol(
        self,
        symbol_isin: str,
        timeout: Optional[int] = None,
    ) -> PositionsResponse:
        """
        Get the positions for a symbol.

        Args:
            symbol_isin (str): The symbol ISIN to get the positions for.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            PositionsResponse: The positions response for the symbol.

        Raises:
            GrowwClientException: If the request fails.
        """
        response: dict[str, any] = super().get_position_for_symbol(
            symbol_isin=symbol_isin,
            timeout=timeout,
        )
        return PositionsResponse(**response)

    def get_positions_for_user(
        self,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> SymbolToPositionsResponse:
        """
        Get the positions for the user for all the symbols they have positions in.

        Args:
            segment (Segment): The segment of the positions.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            SymbolToPositionsResponse: The user's positions response.

        Raises:
            GrowwClientException: If the request fails.
        """
        response: dict[str, any] = super().get_positions_for_user(
            segment=segment,
            timeout=timeout,
        )
        return SymbolToPositionsResponse(**response)

    def get_trade_list_for_order(
        self,
        groww_order_id: str,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> TradeResponse:
        """
        Get the list of trades for a specific order.

        Args:
            groww_order_id (str): The Groww order ID.
            segment (Segment): The segment of the order.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            TradeResponse: The list of trades response.

        Raises:
            GrowwClientException: If the request fails.
        """
        response: dict[str, any] = super().get_trade_list_for_order(
            groww_order_id=groww_order_id,
            segment=segment,
            timeout=timeout,
        )
        return TradeResponse(**response)

    def get_available_margin_details(self, timeout: Optional[int] = None) -> dict:
        """
        Get the available margin details for the user.

        Args:
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            dict: The available margin details response.

        Raises:
            GrowwClientException: If the request fails.
        """
        response : dict[str, any] = super().get_available_margin_details(timeout=timeout)
        return MarginAvailableResponse(**response)

    def download_instrument_csv(self, path, timeout: Optional[int] = None):
        """
        Download the instruments CSV file from the Groww API.

        Args:
            path (str): The path to save the CSV file to.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Raises:
            GrowwClientException: If the request fails.
        """
        super().download_instrument_csv(path=path, timeout=timeout)

    def get_historical_candle_data(self, symbol: str, exchange: Exchange, segment: Segment, start_time_in_millis: str, end_time_in_millis: str, interval_in_minutes: Optional[int] = None, timeout: Optional[int] = None) -> dict:
        """
        Get historical candle data for a symbol.

        Args:
            symbol (str): The symbol to fetch the data for.
            exchange (Exchange): The exchange to fetch the data from.
            segment (Segment): The segment to fetch the data from.
            start_time_in_millis (int): The start time in milliseconds.
            end_time_in_millis (int): The end time in milliseconds.
            interval_in_minutes (Optional[int]): The interval in minutes. Defaults to None.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).
        """
        response : dict[str, any] = super().get_historical_candle_data(symbol, exchange, segment, start_time_in_millis, end_time_in_millis, interval_in_minutes, timeout)
        return HistoricalCandleDataResponse(**response)