"""
Data stores for Groww data models.

Contains abstract and concrete classes for storing various Groww data models.
"""

from abc import ABC, abstractmethod
from typing import Optional

from gwapex.groww.models import BaseGrowwModel, OrderDetailDto

from gwapex.groww.enums import InstrumentType
from gwapex.groww.models import Instrument


class BaseGrowwDataStore(ABC):
    """
    Abstract class for storing Groww data models.
    """

    def __init__(self):
        super().__init__()
        self.initialise()

    @abstractmethod
    def initialise(self) -> None:
        """
        Initialise the data store.
        """

    @abstractmethod
    def load(self, data: list[BaseGrowwModel]) -> None:
        """
        Load the data store.

        Args:
            data (list[BaseGrowwModel]): The data to load.
        """


class InstrumentGrowwDataStore(BaseGrowwDataStore):
    """
    Data store for storing instrument data.
    """

    def initialise(self):
        self._instrument_map: dict[InstrumentType, dict[str, Instrument]] = {}
        for it in InstrumentType.values():
            self._instrument_map[it] = {}

    def load(self, data: list[Instrument]) -> None:
        """
        Load the instruments into the data store.

        Args:
            data (list[Instrument]): The instruments to load.
        """
        self._upsert_all(data)

    def get_instrument(
        self,
        instrument_id: str,
        instrument_type: InstrumentType,
    ) -> Optional[Instrument]:
        """
        Get an instrument by ID and type.

        Args:
            instrument_id (str): The ID of the instrument.
            instrument_type (InstrumentType): The type of the instrument.

        Returns:
            Optional[Instrument]: The instrument, if found.
        """
        return self._instrument_map.get(instrument_type, {}).get(instrument_id, None)

    def _upsert_all(self, instruments: list[Instrument]) -> None:
        """
        Upsert all the instruments in the data store.

        Args:
            instruments (list[Instrument]): The instruments to upsert.
        """
        for i in instruments:
            self._instrument_map[i.instrument_type][i.exchange_instrument_id] = i


class OrderListGrowwDataStore(BaseGrowwDataStore):
    """
    Data store for storing order list data.
    """

    def initialise(self):
        self._order_map: dict[str, OrderDetailDto] = {}

    def load(self, data: list[OrderDetailDto]) -> None:
        """
        Load the order list into the data store.

        Args:
            data (list[OrderDetailDto]): The order list to load.
        """
        self._upsert_all(data)

    def get_order(self, groww_order_id: str) -> Optional[OrderDetailDto]:
        """
        Get an order by Groww order ID.

        Args:
            groww_order_id (str): The Groww order ID.

        Returns:
            Optional[OrderDetailDto]: The order detail, if found.
        """
        return self._order_map.get(groww_order_id, None)

    def upsert_order(self, order: OrderDetailDto) -> None:
        """
        Upsert an order into the data store.

        Args:
            order (OrderDetailDto): The order to upsert.
        """
        self._order_map[order.groww_order_id] = order

    def delete_order(self, groww_order_id: str) -> None:
        """
        Delete an order from the data store.

        Args:
            groww_order_id (str): The Groww order ID of the order to delete.
        """
        if groww_order_id in self.order_map:
            del self._order_map[groww_order_id]

    def _upsert_all(self, orders: list[OrderDetailDto]) -> None:
        """
        Upsert all the orders in the data store.

        Args:
            orders (list[OrderDetailDto]): The orders to upsert.
        """
        for order in orders:
            self.upsert_order(order)
