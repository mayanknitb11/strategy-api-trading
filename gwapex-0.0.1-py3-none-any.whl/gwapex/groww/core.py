"""
Core module for the Groww Apex SDK.
"""

from typing import Optional, Callable

from gwapex.groww.models import *
from gwapex.groww.responses import *

from gwapex.groww.client import StructuredGrowwClient
from gwapex.groww.enums import InstrumentType
from gwapex.groww.etl import InstrumentCsvGrowwEtl, OrderListApiGrowwEtl
from gwapex.groww.feed import StructuredGrowwFeed
from gwapex.groww.models import (
    Instrument,
    IndexFutureContract,
    StockFutureContract,
    IndexInstrument,
    IndexOptionContract,
    StockOptionContract,
    StockInstrument,
)
from gwapex.groww.stores import InstrumentGrowwDataStore, OrderListGrowwDataStore


class Groww:
    """
    The main Groww class.
    """

    def __init__(
        self,
        api_token: str,
        api_key: str,
        socket_token: str,
        socket_key: str,
    ) -> None:
        """
        Initialize the Groww class.

        Args:
            api_token (str): The API token.
            api_key (str): The API key.
            socket_token (str): The socket token.
            socket_key (str): The socket key.

        Raises:
            GrowwFeedConnectionException: If the socket connection fails.
        """
        self._client = StructuredGrowwClient(api_token, api_key)
        self._feed = StructuredGrowwFeed(socket_token, socket_key)
        self._internal_feed = StructuredGrowwFeed(socket_token, socket_key)
        self._instrument_manager = InstrumentManager(self._client)
        self._order_manager = OrderManager(self._client, self._internal_feed)

    def get_index(self, instrument_id: str) -> Optional[IndexInstrument]:
        """
        Get an Index instrument by ID.

        Args:
            instrument_id (str): The ID of the instrument.

        Returns:
            Optional[IndexInstrument]: The Index instrument, if found.
        """
        return self._get_instrument(instrument_id, InstrumentType.INDEX)

    def get_index_future(self, instrument_id: str) -> Optional[IndexFutureContract]:
        """
        Get an Index Future instrument by ID.

        Args:
            instrument_id (str): The ID of the instrument.

        Returns:
            Optional[IndexFutureContract]: The Index Future instrument, if found.
        """
        return self._get_instrument(instrument_id, InstrumentType.INDEX_FUTURE)

    def get_index_option(self, instrument_id: str) -> Optional[IndexOptionContract]:
        """
        Get Index Option instrument by ID.

        Args:
            instrument_id (str): The ID of the instrument.

        Returns:
            Optional[IndexOptionContract]: The Index Option instrument, if found.
        """
        return self._get_instrument(instrument_id, InstrumentType.INDEX_OPTION)

    def get_stock(self, instrument_id: str) -> Optional[StockInstrument]:
        """
        Get a Stock instrument by ID.

        Args:
            instrument_id (str): The ID of the instrument.

        Returns:
            Optional[StockInstrument]: The Stock instrument, if found.
        """
        return self._get_instrument(instrument_id, InstrumentType.STOCK)

    def get_stock_future(self, instrument_id: str) -> Optional[StockFutureContract]:
        """
        Get a Stock Future instrument by ID.

        Args:
            instrument_id (str): The ID of the instrument.

        Returns:
            Optional[StockFutureContract]: The Stock Future instrument, if found.
        """
        return self._get_instrument(instrument_id, InstrumentType.STOCK_FUTURE)

    def get_stock_option(self, instrument_id: str) -> Optional[StockOptionContract]:
        """
        Get a Stock Option instrument by ID.

        Args:
            instrument_id (str): The ID of the instrument.

        Returns:
            Optional[StockOptionContract]: The Stock Option instrument, if found.
        """
        return self._get_instrument(instrument_id, InstrumentType.STOCK_OPTION)

    def cancel_order(
        self,
        groww_order_id: str,
        segment: Segment,
        order_reference_id: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> CancelOrderResponse:
        """
        Cancel an existing order.

        Args:
            groww_order_id (str): The Groww order ID.
            segment (Segment): The segment of the order.
            order_reference_id (Optional[str]): The order reference ID.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            CancelOrderResponse: The cancelled order response.

        Raises:
            GrowwClientException: If the request fails.
        """
        return self._client.cancel_order(
            groww_order_id=groww_order_id,
            segment=segment,
            order_reference_id=order_reference_id,
            timeout=timeout,
        )

    def get_holdings_for_user(self, timeout: Optional[int] = None) -> HoldingsResponse:
        """
        Get the holdings for the user.

        Args:
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            HoldingsResponse: The user's holdings response.

        Raises:
            GrowwClientException: If the request fails.
        """
        return self._client.get_holdings_for_user(timeout)

    def get_latest_index_data(
        self,
        symbol: str,
        exchange: Exchange,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> LatestIndexResponse:
        """
        Fetch the latest data for an index.

        Args:
            symbol (str): The symbol to fetch the data for.
            exchange (Exchange): The exchange to fetch the data from.
            segment (Segment): The segment to fetch the data from.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            LatestIndexResponse: The latest index data.

        Raises:
            GrowwClientException: If the request fails.
        """
        return self._client.get_latest_index_data(
            symbol=symbol,
            exchange=exchange,
            segment=segment,
            timeout=timeout,
        )

    def get_latest_price_data(
        self,
        symbol: str,
        exchange: Exchange,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> LatestPriceResponse:
        """
        Fetch the latest price data for an instrument.

        Args:
            symbol (str): The symbol to fetch the data for.
            exchange (Exchange): The exchange to fetch the data from.
            segment (Segment): The segment to fetch the data from.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            LatestPriceResponse: The latest price data.

        Raises:
            GrowwClientException: If the request fails.
        """
        return self._client.get_latest_price_data(
            symbol=symbol,
            exchange=exchange,
            segment=segment,
            timeout=timeout,
        )

    def get_market_depth(
        self,
        symbol: str,
        exchange: Exchange,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> MarketDepthResponse:
        """
        Fetch the market depth data for an instrument.

        Args:
            symbol (str): The symbol to fetch the data for.
            exchange (Exchange): The exchange to fetch the data from.
            segment (Segment): The segment to fetch the data from.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            MarketDepthResponse: The market depth data.

        Raises:
            GrowwClientException: If the request fails.
        """
        return self._client.get_market_depth(
            symbol=symbol,
            exchange=exchange,
            segment=segment,
            timeout=timeout,
        )

    def get_order_detail(
        self,
        segment: Segment,
        groww_order_id: str,
        timeout: Optional[int] = None,
    ) -> OrderDetailDto:
        """
        Get the details of an order.

        Args:
            segment (Segment): The segment of the order.
            groww_order_id (str): The Groww order ID.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            OrderDetailDto: The order details response.

        Raises:
            GrowwClientException: If the request fails.
        """
        return self._order_manager.get_order_detail(
            segment=segment,
            groww_order_id=groww_order_id,
            timeout=timeout,
        )

    def get_order_list(
        self,
        segment: Optional[Segment] = None,
        timeout: Optional[int] = None,
    ) -> OrderListResponse:
        """
        Get a list of orders.

        Args:
            segment (Optional[Segment]): The segment of the orders.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            OrderListResponse: The list of orders response.

        Raises:
            GrowwClientException: If the request fails.
        """
        return self._client.get_order_list(segment=segment, timeout=timeout)

    def get_position_for_symbol(
        self,
        symbol_isin: str,
        timeout: Optional[int] = None,
    ) -> PositionsResponse:
        """
        Get the positions for a symbol.

        Args:
            symbol_isin (str): The symbol ISIN to get the positions for.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            PositionsResponse: The positions response for the symbol.

        Raises:
            GrowwClientException: If the request fails.
        """
        return self._client.get_position_for_symbol(
            symbol_isin=symbol_isin,
            timeout=timeout,
        )

    def get_positions_for_user(
        self,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> SymbolToPositionsResponse:
        """
        Get the positions for the user for all the symbols they have positions in.

        Args:
            segment (Segment): The segment of the positions.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            SymbolToPositionsResponse: The user's positions response.

        Raises:
            GrowwClientException: If the request fails.
        """
        return self._client.get_positions_for_user(segment=segment, timeout=timeout)

    def get_trade_list_for_order(
        self,
        groww_order_id: str,
        segment: Segment,
        timeout: Optional[int] = None,
    ) -> TradeResponse:
        """
        Get the list of trades for a specific order.

        Args:
            groww_order_id (str): The Groww order ID.
            segment (Segment): The segment of the order.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            TradeResponse: The list of trades response.

        Raises:
            GrowwClientException: If the request fails.
        """
        return self._client.get_trade_list_for_order(
            groww_order_id=groww_order_id,
            segment=segment,
            timeout=timeout,
        )

    def modify_order(
        self,
        order_type: OrderType,
        price: float,
        qty: int,
        segment: Segment,
        groww_order_id: Optional[str] = None,
        order_reference_id: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> ModifyOrderResponse:
        """
        Modify an existing order.

        Args:
            order_type (OrderType): The type of order.
            price (float): The price of the order.
            qty (int): The quantity of the order.
            segment (Segment): The segment of the order.
            groww_order_id (Optional[str]): The Groww order ID.
            order_reference_id (Optional[str]): The order reference ID.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            ModifyOrderResponse: The modified order response.

        Raises:
            GrowwClientException: If the request fails.
        """
        return self._client.modify_order(
            order_type=order_type,
            price=price,
            qty=qty,
            segment=segment,
            groww_order_id=groww_order_id,
            order_reference_id=order_reference_id,
            timeout=timeout,
        )

    def place_order(
        self,
        duration: Duration,
        exchange: Exchange,
        order_type: OrderType,
        price: float,
        product: Product,
        qty: int,
        segment: Segment,
        symbol: str,
        transaction_type: TransactionType,
        timeout: Optional[int] = None,
    ) -> OrderResponse:
        """
        Place a new order.

        Args:
            duration (Duration): The duration of the order.
            exchange (Exchange): The exchange to place the order on.
            order_type (OrderType): The type of order.
            price (float): The price of the order.
            product (Product): The product type.
            qty (int): The quantity of the order.
            segment (Segment): The segment of the order.
            symbol (str): The symbol to place the order for.
            transaction_type (TransactionType): The transaction type.
            timeout (Optional[int]): The timeout for the request in seconds. Defaults to None (infinite).

        Returns:
            OrderResponse: The placed order response.

        Raises:
            GrowwClientException: If the request fails.
        """
        return self._client.place_order(
            duration=duration,
            exchange=exchange,
            order_type=order_type,
            price=price,
            product=product,
            qty=qty,
            segment=segment,
            symbol=symbol,
            transaction_type=transaction_type,
            timeout=timeout,
        )

    def subscribe_derivatives_live(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the live data of a derivatives contract.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._feed.subscribe_derivatives_live(subscription_key, on_data_received)

    def unsubscribe_derivatives_live(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the live data of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._feed.unsubscribe_derivatives_live(subscription_key)

    def subscribe_derivatives_market_depth(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the market depth of a derivatives contract.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._feed.subscribe_derivatives_market_depth(
            subscription_key,
            on_data_received,
        )

    def unsubscribe_derivatives_market_depth(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the market depth of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._feed.unsubscribe_derivatives_market_depth(subscription_key)

    def subscribe_derivatives_order_updates(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the order updates of a derivatives contract.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._feed.subscribe_derivatives_order_updates(
            subscription_key,
            on_data_received,
        )

    def unsubscribe_derivatives_order_updates(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the order updates of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._feed.unsubscribe_derivatives_order_updates(subscription_key)

    def subscribe_derivatives_position_updates(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the position updates of a derivatives contract.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._feed.subscribe_derivatives_position_updates(
            subscription_key,
            on_data_received,
        )

    def unsubscribe_derivatives_position_updates(
        self,
        subscription_key: str,
    ) -> bool:
        """
        Unsubscribe from the position updates of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._feed.unsubscribe_derivatives_position_updates(subscription_key)

    def subscribe_indices_live(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the live data of an index.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._feed.subscribe_indices_live(subscription_key, on_data_received)

    def unsubscribe_indices_live(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the live data of an index.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._feed.unsubscribe_indices_live(subscription_key)

    def subscribe_market_info(
        self,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the market information.

        Subscription can be created only once for a given subscription key.

        Args:
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._feed.subscribe_market_info(on_data_received)

    def unsubscribe_market_info(self) -> bool:
        """
        Unsubscribe from the market information.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._feed.unsubscribe_market_info()

    def subscribe_stocks_live(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the live data of a stock.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._feed.subscribe_stocks_live(subscription_key, on_data_received)

    def unsubscribe_stocks_live(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the live data of a stock.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._feed.unsubscribe_stocks_live(subscription_key)

    def subscribe_stocks_market_depth(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        return self._order_manager.get_order_detail(groww_order_id)
        Subscribe to the market depth of a stock.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._feed.subscribe_stocks_market_depth(
            subscription_key,
            on_data_received,
        )

    def unsubscribe_stocks_market_depth(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the market depth of a stock.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._feed.unsubscribe_stocks_market_depth(subscription_key)

    def subscribe_stocks_order_updates(
        self,
        subscription_key: str,
        on_data_received: Optional[Callable[[], None]] = None,
    ) -> bool:
        """
        Subscribe to the order updates of a stock.

        Subscription can be created only once for a given subscription key.

        Args:
            subscription_key (str): The subscription key.
            on_data_received (Optional[Callable[[], None]]): The callback function to call on data update.

        Returns:
            bool: True if a new subscription was created, False otherwise.
        """
        return self._feed.subscribe_stocks_order_updates(
            subscription_key,
            on_data_received,
        )

    def unsubscribe_stocks_order_updates(self, subscription_key: str) -> bool:
        """
        Unsubscribe from the order updates of a stock.

        Args:
            subscription_key (str): The subscription key.

        Returns:
            bool: True if existing subscription was unsubscribed, False otherwise.
        """
        return self._feed.unsubscribe_stocks_order_updates(subscription_key)

    def get_derivatives_live_from_sub(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[LivePriceData]:
        """
        Get the live data of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[LivePriceData]: The live price data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        return self._feed.get_derivatives_live(subscription_key, timeout)

    def get_derivatives_ltp_from_sub(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[float]:
        """
        Get the last traded price (LTP) of an option contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[float]: The last traded price, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        return self._feed.get_derivatives_ltp(subscription_key, timeout)

    def get_derivatives_market_depth_from_sub(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[MarketDepthData]:
        """
        Get the market depth of an option contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[MarketDepthData]: The market depth data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        return self._feed.get_derivatives_market_depth(subscription_key, timeout)

    def get_derivatives_order_update_from_sub(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[OrderDetailDto]:
        """
        Get the order updates of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[OrderDetailDto]: The order details, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        return self._feed.get_derivatives_order_update(subscription_key, timeout)

    def get_derivatives_position_update_from_sub(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[ExchangePosition]:
        """
        Get the position updates of a derivatives contract.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[ExchangePosition]: The exchange wise position, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        return self._feed.get_derivatives_position_update(subscription_key, timeout)

    def get_indices_live_from_sub(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[LiveIndexData]:
        """
        Get the live data of an index.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[LiveIndexData]: The live index data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        return self._feed.get_indices_live(subscription_key, timeout)

    def get_indices_value_from_sub(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[float]:
        """
        Get the last value of an index.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[float]: The last value of the Index, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        return self._feed.get_indices_value(subscription_key, timeout)

    def get_market_info_from_sub(self, timeout: float = 5) -> Optional[str]:
        """
        Get the market information.

        Args:
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[any]: The market information, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        return self._feed.get_market_info(timeout)

    def get_stocks_live_from_sub(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[LivePriceData]:
        """
        Get the live data of a stock.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[LivePriceData]: The live price data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        return self._feed.get_stocks_live(subscription_key, timeout)

    def get_stocks_ltp_from_sub(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[float]:
        """
        Get the last traded price (LTP) of a stock.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[float]: The last traded price, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        return self._feed.get_stocks_ltp(subscription_key, timeout)

    def get_stocks_market_depth_from_sub(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[MarketDepthData]:
        """
        Get the market depth of a stock.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[MarketDepthData]: The market depth data, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        return self._feed.get_stocks_market_depth(subscription_key, timeout)

    def get_stocks_order_update_from_sub(
        self,
        subscription_key: str,
        timeout: float = 5,
    ) -> Optional[OrderDetailDto]:
        """
        Get the order updates of a stock.

        Args:
            subscription_key (str): The subscription key.
            timeout (float): The timeout in seconds for getting the data.

        Returns:
            Optional[OrderDetailDto]: The order details, or None if data is not available.

        Raises:
            GrowwFeedNotSubscribedException: If the feed was not subscribed before attempting to get.
        """
        return self._feed.get_stocks_order_update(subscription_key, timeout)

    def _get_instrument(
        self,
        instrument_id: str,
        instrument_type: InstrumentType,
    ) -> Optional[Instrument]:
        """
        Fetches an instrument by ID and type.

        Args:
            instrument_id (str): The ID of the instrument to fetch.
            instrument_type (InstrumentType): The type of the instrument.

        Returns:
            Optional[Instrument]: The instrument, if found.
        """
        return self._instrument_manager.get_instrument(instrument_id, instrument_type)


class InstrumentManager:
    """
    Instrument manager class.
    """

    def __init__(self, groww_client:StructuredGrowwClient) -> None:
        """
        Initialize the InstrumentManager.
        """

        self._data_store = InstrumentGrowwDataStore()
        self._etl = InstrumentCsvGrowwEtl(self._data_store, groww_client)
        self._etl.run()

    def get_instrument(
        self,
        instrument_id: str,
        instrument_type: InstrumentType,
    ) -> Optional[Instrument]:
        """
        Get an instrument by ID and type.

        Args:
            instrument_id (str): The ID of the instrument.
            instrument_type (InstrumentType): The type of the instrument.

        Returns:
            Optional[Instrument]: The instrument, if found.
        """
        return self._data_store.get_instrument(instrument_id, instrument_type)


class OrderManager:
    """
    Order manager class.
    """

    def __init__(self, client: StructuredGrowwClient, feed: StructuredGrowwFeed) -> None:
        """
        Initialize the OrderManager.

        Args:
            client (StructuredGrowwClient): The Groww client.
            feed (GrowwFeed): The Groww feed.
        """
        self.client = client
        self.feed = feed
        self._data_store = OrderListGrowwDataStore()
        self._etl = OrderListApiGrowwEtl(self._data_store, self.client)
        self._etl.run()
        self.feed.subscribe_stocks_order_updates(
            str,
            on_data_received=self._update_stocks_order_from_feed,
        )
        self.feed.subscribe_derivatives_order_updates(
            str,
            on_data_received=self._update_derivatives_order_from_feed,
        )

    def get_order_detail(
        self,
        segment: Segment,
        groww_order_id: str,
        timeout: Optional[int] = None,
    ) -> OrderDetailDto:
        """
        Get the order detail by its Groww Order ID.

        Args:
            groww_order_id (str): The Groww Order ID of the Order.
            timeout (Optional[int], optional): The timeout for the request. Defaults to None (infinite).

        Returns:
            OrderDetailDto: The order detail.
        """
        order: OrderDetailDto = self._data_store.get_order(groww_order_id)
        if not order or order.order_status.is_open():
            order = self.client.get_order_detail(
                segment=segment,
                groww_order_id=groww_order_id,
                timeout=timeout,
            )
            self._data_store.upsert_order(order)
        return order

    def _update_derivatives_order_from_feed(self) -> None:
        """
        Update new derivatives order from feed.
        """
        order: Optional[OrderDetailDto] = self.feed.get_stocks_order_update()
        self._data_store.upsert_order(order) if order else None

    def _update_stocks_order_from_feed(self) -> None:
        """
        Update new stocks order from feed.
        """
        order: Optional[OrderDetailDto] = self.feed.get_stocks_order_update()
        self._data_store.upsert_order(order) if order else None
