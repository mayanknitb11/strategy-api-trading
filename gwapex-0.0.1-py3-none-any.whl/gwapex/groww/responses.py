"""
This module contains response models for Groww API.
"""

from typing import Optional

from pydantic import Field

from gwapex_base.groww.enums import Product, OrderStatus
from gwapex.groww.models import (
    BaseGrowwModel,
    ExchangePosition,
    Holding,
    LiveIndexData,
    LivePriceData,
    MarketDepthData,
    OrderDetailDto,
    Trade, MarginAvailable,
    HistoricalCandleData
)


class BaseGrowwResponse(BaseGrowwModel):
    """Base class for all Groww responses."""


class CancelOrderResponse(BaseGrowwResponse):
    """Response model for cancelled order information."""

    groww_order_id: str = Field(..., alias="growwOrderId")
    order_reference_id: Optional[str] = Field(None, alias="orderReferenceId")
    order_status: OrderStatus = Field(..., alias="orderStatus")
    remark: Optional[str] = None


class HoldingsResponse(BaseGrowwResponse):
    """Response model for holdings information."""

    holdings: list[Holding]


class LatestIndexResponse(BaseGrowwResponse, LiveIndexData):
    """Response model for live index data."""

    pass


class LatestPriceResponse(BaseGrowwResponse, LivePriceData):
    """Response model for live price data."""

    pass


class MarketDepthResponse(BaseGrowwResponse, MarketDepthData):
    """Response model for market depth data."""

    pass


class ModifyOrderResponse(BaseGrowwResponse):
    """Response model for modified order information."""

    groww_order_id: str = Field(..., alias="growwOrderId")
    order_reference_id: Optional[str] = Field(None, alias="orderReferenceId")
    order_status: OrderStatus = Field(..., alias="orderStatus")
    remark: Optional[str] = None


class OrderDetailResponse(BaseGrowwResponse, OrderDetailDto):
    """Response model for order detail information."""

    pass


class OrderListResponse(BaseGrowwResponse):
    """Response model for a list of orders."""

    order_list: list[OrderDetailDto] = Field(..., alias="orderList")


class OrderResponse(BaseGrowwResponse):
    """Response model for order information."""

    groww_order_id: str = Field(..., alias="growwOrderId")
    order_reference_id: Optional[str] = Field(None, alias="orderReferenceId")
    order_status: OrderStatus = Field(..., alias="orderStatus")
    remark: Optional[str] = None


class TradeResponse(BaseGrowwResponse):
    """Response model for trade information."""

    trade_list: list[Trade] = Field(..., alias="tradeList")


class PositionsResponse(BaseGrowwResponse):
    """Response model for position information."""

    symbol_isin: Optional[str] = Field(None, alias="symbolIsin")
    product_wise_positions: dict[Product, ExchangePosition] = Field(
        ...,
        alias="productWisePositions",
    )


class SymbolToPositionsResponse(BaseGrowwResponse):
    """Response model for symbol to positions information."""

    symbol_wise_positions: dict[str, PositionsResponse] = Field(
        ..., alias="symbolWisePositions"
    )

class MarginAvailableResponse(BaseGrowwResponse, MarginAvailable):
    """Response model for margin available information."""
    pass

class HistoricalCandleDataResponse(BaseGrowwResponse, HistoricalCandleData):
    """Response model for historical candle data information."""
    pass
