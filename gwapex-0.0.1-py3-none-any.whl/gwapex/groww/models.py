"""
Models for Apex-advanced SDK.
"""
from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel, Field, field_validator

from gwapex.groww.enums import InstrumentType, OptionType
from gwapex_base.groww.enums import (
    AmoStatus,
    Duration,
    EquityType,
    Exchange,
    OrderStatus,
    OrderType,
    Product,
    Segment,
    TransactionType,
)


class BaseGrowwModel(BaseModel):
    """Base class for all Groww models."""


class BookData(BaseGrowwModel):
    """Model for an individual Buy/Sell book DTO"""

    price: Optional[float] = None
    quantity: Optional[int] = Field(None, alias="qty")


class ExchangePosition(BaseGrowwModel):
    """Model representing exchanges mapped to position details."""

    symbol_isin: Optional[str] = Field(None, alias="symbolIsin")
    exchange_position: dict[Exchange, "PositionDetailDto"] = Field(
        ...,
        alias="exchangePosition",
    )


class Holding(BaseGrowwModel):
    """Model representing a holding."""

    active_demat_transfer_qty: Optional[int] = Field(
        None, alias="activeDematTransferQty"
    )
    avg_price: Optional[int] = Field(None, alias="avgPrice")
    ca_additional_qty: Optional[int] = Field(None, alias="caAdditionalQty")
    demat_free_qty: Optional[float] = Field(None, alias="dematFreeQty")
    demat_locked_qty: Optional[float] = Field(None, alias="dematLockedQty")
    groww_locked_qty: Optional[float] = Field(None, alias="growwLockedQty")
    net_qty: Optional[float] = Field(None, alias="netQty")
    pledge_qty: Optional[float] = Field(None, alias="pledgeQty")
    repledge_qty: Optional[float] = Field(None, alias="repledgeQty")
    symbol_isin: Optional[str] = Field(None, alias="symbolIsin")
    t1_qty: Optional[float] = Field(None, alias="t1Qty")


class LiveIndexData(BaseGrowwModel):
    """Model representing live index data."""

    close: Optional[float] = None
    day_change: Optional[float] = Field(None, alias="dayChange")
    day_change_perc: Optional[float] = Field(None, alias="dayChangePerc")
    high: Optional[float] = None
    low: Optional[float] = None
    open: Optional[float] = None
    value: Optional[float] = None
    week52_high: Optional[float] = Field(None, alias="week52High")
    week52_low: Optional[float] = Field(None, alias="week52Low")


class LivePriceData(BaseGrowwModel):
    """Model representing live price data."""

    avg_price: Optional[float] = Field(None, alias="avgPrice")
    bid_qty: Optional[int] = Field(None, alias="bidQty")
    bid_price: Optional[float] = Field(None, alias="bidPrice")
    close: Optional[float] = None
    day_change: Optional[float] = Field(None, alias="dayChange")
    day_change_perc: Optional[float] = Field(None, alias="dayChangePerc")
    high: Optional[float] = None
    high_price_range: Optional[float] = Field(None, alias="highPriceRange")
    high_trade_range: Optional[float] = Field(None, alias="highTradeRange")
    implied_volatility: Optional[float] = Field(None, alias="impliedVolatility")
    last_trade_qty: Optional[int] = Field(None, alias="lastTradeQty")
    last_trade_time: Optional[int] = Field(None, alias="lastTradeTime")
    low: Optional[float] = None
    low_price_range: Optional[float] = Field(None, alias="lowPriceRange")
    low_trade_range: Optional[float] = Field(None, alias="lowTradeRange")
    ltp: Optional[float] = None
    market_cap: Optional[float] = Field(None, alias="marketCap")
    offer_price: Optional[float] = Field(None, alias="offerPrice")
    offer_qty: Optional[int] = Field(None, alias="offerQty")
    oi_day_change: Optional[float] = Field(None, alias="oiDayChange")
    oi_day_change_perc: Optional[float] = Field(None, alias="oiDayChangePerc")
    open: Optional[float] = None
    open_interest: Optional[float] = Field(None, alias="openInterest")
    prev_open_interest: Optional[float] = Field(None, alias="prevOpenInterest")
    total_buy_qty: Optional[float] = Field(None, alias="totalBuyQty")
    total_sell_qty: Optional[float] = Field(None, alias="totalSellQty")
    volume: Optional[int] = None
    week52_high: Optional[float] = Field(None, alias="week52High")
    week52_low: Optional[float] = Field(None, alias="week52Low")


class MarketDepthData(BaseGrowwModel):
    """Market Depth Book Data Model for a Instrument"""

    buy_book: Optional[dict[int, BookData]] = Field({}, alias="buyBook")
    sell_book: Optional[dict[int, BookData]] = Field({}, alias="sellBook")


class OrderDetailDto(BaseGrowwModel):
    """Model representing an order detail."""

    amo_status: Optional[AmoStatus] = Field(None, alias="amoStatus")
    avg_fill_price: Optional[int] = Field(None, alias="avgFillPrice")
    buy_sell: Optional[TransactionType] = Field(None, alias="buySell")
    contract_id: Optional[str] = Field(None, alias="contractId")
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    deliverable_qty: Optional[int] = Field(None, alias="deliverableQty")
    duration: Duration = Field(..., alias="duration")
    equity_type: Optional[EquityType] = Field(None, alias="equityType")
    exchange: Exchange = Field(..., alias="exchange")
    exchange_creation_time: Optional[datetime] = Field(
        None,
        alias="exchangeCreationTime",
    )
    exchange_order_id: Optional[str] = Field(None, alias="exchangeOrderId")
    exchange_time: Optional[datetime] = Field(None, alias="exchangeTime")
    exchange_update_time: Optional[datetime] = Field(None, alias="exchangeUpdateTime")
    filled_qty: Optional[int] = Field(None, alias="filledQty")
    groww_order_id: str = Field(..., alias="growwOrderId")
    gui_order_id: Optional[str] = Field(None, alias="guiOrderId")
    is_cancellation_allowed: Optional[bool] = Field(None, alias="isCancellationAllowed")
    is_modification_allowed: Optional[bool] = Field(None, alias="isModificationAllowed")
    order_reference_id: Optional[str] = Field(None, alias="orderReferenceId")
    order_status: OrderStatus = Field(..., alias="orderStatus")
    order_type: Optional[OrderType] = Field(None, alias="orderType")
    price: Optional[int] = None
    product: Product = Field(..., alias="product")
    quantity: int = Field(..., alias="qty")
    remaining_quantity: Optional[int] = Field(None, alias="remainingQty")
    remark: Optional[str] = None
    segment: Segment = Field(..., alias="segment")
    symbol: Optional[str] = Field(None, alias="symbol")
    symbol_name: Optional[str] = Field(None, alias="symbolName")
    trade_date: Optional[datetime] = Field(None, alias="tradeDate")
    trigger_price: Optional[int] = Field(None, alias="triggerPrice")
    updated_at: Optional[datetime] = Field(None, alias="updatedAt")


class PositionDetailDto(BaseGrowwModel):
    """Model representing a position detail."""

    credit_quantity: Optional[int] = Field(None, alias="creditQty")
    credit_price: Optional[int] = Field(None, alias="creditPrice")
    debit_quantity: Optional[int] = Field(None, alias="debitQty")
    debit_price: Optional[int] = Field(None, alias="debitPrice")
    cf_credit_quantity: Optional[int] = Field(None, alias="cfCreditQty")
    cf_credit_price: Optional[int] = Field(None, alias="cfCreditPrice")
    cf_debit_quantity: Optional[int] = Field(None, alias="cfDebitQty")
    cf_debit_price: Optional[int] = Field(None, alias="cfDebitPrice")
    is_valid: Optional[bool] = Field(None, alias="isValid")


class Trade(BaseGrowwModel):
    """Model representing a trade."""

    buy_sell: Optional[str] = Field(None, alias="buySell")
    contract_id: Optional[str] = Field(None, alias="contractId")
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    exchange: Optional[Exchange] = None
    exchange_order_id: Optional[str] = Field(None, alias="exchangeOrderId")
    exchange_trade_id: Optional[str] = Field(None, alias="exchangeTradeId")
    exchange_update_time: Optional[datetime] = Field(None, alias="exchangeUpdateTime")
    groww_order_id: Optional[str] = Field(None, alias="growwOrderId")
    groww_trade_id: Optional[str] = Field(None, alias="growwTradeId")
    nest_update_micros: Optional[int] = Field(None, alias="nestUpdateMicros")
    nest_update_time: Optional[datetime] = Field(None, alias="nestUpdateTime")
    price: Optional[int] = None
    product: Optional[Product] = None
    qty: Optional[int] = None
    remark: Optional[str] = None
    segment: Optional[Segment] = None
    settlement_number: Optional[str] = Field(None, alias="settlementNumber")
    symbol: Optional[str] = None
    symbol_isin: Optional[str] = Field(None, alias="symbolIsin")
    symbol_name: Optional[str] = Field(None, alias="symbolName")
    trade_date_time: Optional[datetime] = Field(None, alias="tradeDateTime")
    trade_status: Optional[str] = Field(None, alias="tradeStatus")
    unique_client_code: Optional[str] = Field(None, alias="uniqueClientCode")

class Instrument(BaseGrowwModel):
    """
    Model for instrument data.
    """

    exchange_instrument_id: str
    symbol: str
    symbol_name: str
    exchange: Exchange
    buy_allowed: bool
    sell_allowed: bool
    instrument_type: InstrumentType


class IndexInstrument(Instrument):
    """
    Model for Index instrument data.
    """

    instrument_type: InstrumentType = InstrumentType.INDEX


class StockInstrument(Instrument):
    """
    Model for stock instrument data.
    """

    instrument_type: InstrumentType = InstrumentType.STOCK


class DerivativeContract(Instrument):
    """
    Model for future contract data.
    """

    underlying_symbol: str
    underlying_instrument_id: str
    lot_size: int
    expiry_date: str
    tick_size: float


class IndexFutureContract(DerivativeContract):
    """
    Model for future index contract data.
    """

    instrument_type: InstrumentType = InstrumentType.INDEX_FUTURE


class StockFutureContract(DerivativeContract):
    """
    Model for future stock contract data.
    """

    instrument_type: InstrumentType = InstrumentType.STOCK_FUTURE


class OptionContract(DerivativeContract):
    """
    Model for option contract data.
    """

    strike_price: float
    option_type: OptionType


class IndexOptionContract(OptionContract):
    """
    Model for option index contract data.
    """

    instrument_type: InstrumentType = InstrumentType.INDEX_OPTION


class StockOptionContract(OptionContract):
    """
    Model for option stock contract data.
    """

    instrument_type: InstrumentType = InstrumentType.STOCK_OPTION

class FnoMarginDetails(BaseGrowwModel):
    """
    Model for FNO margin data.
    """
    net_fno_margin: Optional[float] = Field(None, alias="netFnoMargin")
    span_margin_used: Optional[float] = Field(None, alias="spanMarginUsed")
    exposure_margin_used: Optional[float] = Field(None, alias="exposureMarginUsed")
    future_balance_available: Optional[float] = Field(None,
                                            alias="futureBalanceAvailable")
    option_buy_balance_available: Optional[float] = Field(None,
                                                alias="optionBuyBalanceAvailable")
    option_sell_balance_available: Optional[float] = Field(None,
                                                 alias="optionSellBalanceAvailable")
class EquityMarginDetails(BaseGrowwModel):
    """
    Model for equity margin data.
    """
    net_equity_margin: Optional[float] = Field(None, alias="netEquityMargin")
    cnc_margin_used: Optional[float] = Field(None, alias="cncMarginUsed")
    mis_margin_used: Optional[float] = Field(None, alias="misMarginUsed")
    cnc_balance_available: Optional[float] = Field(None, alias="cncBalanceAvailable")
    mis_balance_available: Optional[float] = Field(None, alias="misBalanceAvailable")

class MarginAvailable(BaseModel):
    """
    Model for margin available data.
    """
    clear_cash: Optional[Optional[float]] = Field(None, alias="clearCash")
    net_margin: Optional[float] = Field(None, alias="netMargin")
    brokerage_and_charges: Optional[float] = Field(None, alias="brokerageAndCharges")
    collateral_used: Optional[float] = Field(None, alias="collateralUsed")
    collateral_available: Optional[float] = Field(None, alias="collateralAvailable")
    adhoc_margin: Optional[float] = Field(None, alias="adhocMargin")
    fno_margin_details: Optional[FnoMarginDetails] = Field(None, alias="fnoMarginDetails")
    equity_margin_details: Optional[EquityMarginDetails] = Field(None,
                                                       alias="equityMarginDetails")


class Candle(BaseModel):
    """
    Model for individual candle data.
    """
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: Optional[int] = None

    @classmethod
    def from_list(cls, data: List):
        return cls(
            timestamp=data[0],
            open=data[1],
            high=data[2],
            low=data[3],
            close=data[4],
            volume=data[5] if len(data) > 5 else None
        )


class HistoricalCandleData(BaseModel):
    """
    Model for historical candle payload data.
    """
    candles: List[Candle]
    start_time_epoch_in_millis: int = Field(..., alias="startTimeEpochInMillis")
    end_time_epoch_in_millis: int = Field(..., alias="endTimeEpochInMillis")
    interval_in_minutes: Optional[int] = Field(None, alias="intervalInMinutes")
    current_page: int = Field(..., alias="currentPage")
    total_pages: int = Field(..., alias="totalPages")
    total_records: int = Field(..., alias="totalRecords")
    has_next: bool = Field(..., alias="hasNext")

    @field_validator('candles', mode='before')
    def convert_candles(cls, v):
        return [Candle.from_list(candle) if isinstance(candle, list) else candle for candle in v]
