"""
Contains all the enums used in the Groww Advanced SDK.
"""

from gwapex_base.groww.enums import BaseGrowwEnum


class InstrumentType(BaseGrowwEnum):
    """
    Enum for instrument type, representing various financial instruments that can be traded.
    """

    INDEX: str = "INDEX"
    """Index - Composite value of a group of stocks representing a market"""

    INDEX_FUTURE: str = "FUTIDX"
    """Index Future - Derivatives contract to buy/sell an index at a future date"""

    INDEX_OPTION: str = "OPTIDX"
    """Index Option - Derivatives contract giving the right to buy/sell an index at a future date"""

    STOCK: str = "STOCKS"
    """Stock - Regular equity shares of a company"""

    STOCK_FUTURE: str = "FUTSTK"
    """Stock Future - Derivatives contract to buy/sell a stock at a future date"""

    STOCK_OPTION: str = "OPTSTK"
    """Stock Option - Derivatives contract giving the right to buy/sell a stock at a future date"""

    ETF: str = "ETF"
    """Exchange Traded Fund - Fund that tracks an index, commodity, or basket of assets"""


class OptionType(BaseGrowwEnum):
    """
    Enum for option type, indicating whether the option is a call or put.
    """

    CALL: str = "CE"
    """Call Option - Right to buy an asset at a specified price before expiration"""

    PUT: str = "PE"
    """Put Option - Right to sell an asset at a specified price before expiration"""
