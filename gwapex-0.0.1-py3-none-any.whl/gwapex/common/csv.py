"""
Utilities to interact with CSV files, including reading and transforming CSV data.
"""

from typing import Callable
import csv


def read_csv_and_transform(
    path: str,
    transform: Callable[[dict], any] = lambda row_data: row_data,
    delimiter: str = ",",
) -> list[any]:
    """
    Read a CSV file and transform each row with a function.

    Args:
        path (str): The path to the CSV file.
        transform (Callable[[dict], Any]): The function to transform each row.
        delimiter (str): The delimiter used in the CSV file.

    Returns:
        List[Any]: The transformed rows.
    """
    with open(path, "r", encoding="utf-8") as file:
        reader = csv.DictReader(file, delimiter=delimiter)
        return [transform(row) for row in reader]
